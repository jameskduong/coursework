let x = 200;
let y = 200;
let r = 24;
let xspeed = 6;
let yspeed = 5;
let score = 0;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0);
  ellipse(x, y, r*2, r*2)
  x+=xspeed;
  y+=yspeed;
  if(x > width-r || x < r ){
   xspeed = -xspeed;
  }
  if(y > height-r || y < r ){
  yspeed = -yspeed;   
  }
  rect(mouseX, 380, 100, 15);
  if((x > mouseX && x < mouseX +100) && (y+15>=378 )){
    score++
  }
  fill("white"); 
  textSize(24);  
  text("SCORE" + " : "+score,10,20);
}